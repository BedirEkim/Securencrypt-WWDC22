enum VisionError: Error {
    case captureSessionSetup(reason: String)
}
